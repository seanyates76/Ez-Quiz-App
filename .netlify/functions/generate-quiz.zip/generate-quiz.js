// netlify/functions/generate-quiz.js
// CommonJS handler for Netlify
const STRICT_PROMPT = (topic, numQuestions, difficulty) => `
You are "EZ-Quiz Strict Formatter". Inputs: topic=${topic}, numQuestions=${numQuestions}, difficulty=${difficulty}.
Output: single JSON array with exactly numQuestions objects { "line": "..." }.
Line grammar:
- MC: MC|Question?|A) opt1;B) opt2;C) opt3;D) opt4|A  (3 pipes, Q? at end, 4 options, answer A-D)
- TF: TF|Statement.|T or TF|Statement.|F           (2 pipes, . at end, answer T/F)
- YN: YN|Question?|Y or YN|Question?|N             (2 pipes, ? at end, answer Y/N)
No markdown, quotes, extra keys or commentary; ASCII only; ≥50% MC; all lines clearly about ${topic}.
Return ONLY the JSON array.
`.trim();

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };
  try {
    const { topic = 'General Knowledge', numQuestions = 5, difficulty = 'easy' } = JSON.parse(event.body || '{}');
    const raw  = await callGemini(STRICT_PROMPT(String(topic), Number(numQuestions), String(difficulty)));
    let arr    = parseArray(raw);
    arr        = sanitizeAndValidate(arr, Number(numQuestions));
    if (arr.length < numQuestions) arr.push(...fallbackLocal(topic, numQuestions - arr.length));
    return json200(arr.slice(0, numQuestions));
  } catch (e) {
    // TEMP: surface real error instead of generic 502
    return { statusCode:500, headers:{'Content-Type':'text/plain'}, body:String(e && e.stack || e) };
  }
};

function json200(x){ return { statusCode:200, headers:{'Content-Type':'application/json'}, body: JSON.stringify(x) }; }

async function callGemini(prompt){
  const key = process.env.GEMINI_API_KEY;
  const model = process.env.GEMINI_MODEL || 'gemini-1.5-pro';
  if (!key) throw new Error("Missing GEMINI_API_KEY");
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;
  const body = { contents:[{ role:'user', parts:[{ text: prompt }] }],
                 generationConfig:{ temperature:0.2, topP:0.1, topK:1, maxOutputTokens:1024 } };
  const res = await fetch(url,{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
  if (!res.ok) throw new Error();
  const j = await res.json();
  return j?.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
}

function parseArray(txt){
  try { const j = JSON.parse(txt); return Array.isArray(j) ? j : []; } catch {}
  return String(txt).split(/\r?\n/).filter(Boolean).map(line => ({ line }));
}

function sanitizeAndValidate(arr, expectN){
  const out = [];
  const mcRe=/^MC\|[^\n?]+\|A\\) [^;]+;B\\) [^;]+;C\\) [^;]+;D\\) [^|]+\|[ABCD]$/;
  const tfRe=/^TF\|[^\n]+\. \|[TF]$/;
  const ynRe=/^YN\|[^|?]+\?\|[YN]$/;

  for (const obj of arr){
    let s = String(obj?.line ?? '').trim();
    if (!s) continue;
    s = s.replace(/[<>]/g,'').replace(/\s+/g,' ');

    if (s.startsWith('TF|')){
      const [_, q='', a='T'] = s.split('|');
      s = `TF|${q.replace(/\.*$/,'')}.|${/^\s*f/i.test(a)?'F':'T'}`;
    } else if (s.startsWith('YN|')){
      const [_, q='', a='Y'] = s.split('|');
      s = `YN|${q.replace(/\?*$/,'')}?|${/^\s*n/i.test(a)?'N':'Y'}`;
    } else if (s.startsWith('MC|')){
      s = s.replace(/^(MC\|[^\n?]+\?)(\s*)(A\))/i,'$1|$3');
      const p = s.split('|');
      if (p.length >= 3){
        const q = p[1].replace(/\?*$/,'') + '?';
        let opts = p[2]
          .replace(/\s*;+\s*/g,'; ')
          .replace(/\s*([A-D])\)\s*/g,(m,g)=>`${g}) `)
          .trim();
        const pick = L => (opts.match(new RegExp(`${L}\\)\s*([^;|]+)`)) || [,'Option '+L])[1].trim();
        const ans = ((p[3]||'').match(/[A-D]/i)?.[0] || 'A').toUpperCase();
        s = `MC|${q}|A) ${pick('A')};B) ${pick('B')};C) ${pick('C')};D) ${pick('D')}|${ans}`;
      }
    }

    if (mcRe.test(s)||tfRe.test(s)||ynRe.test(s)) out.push({ line:s });
    if (out.length === expectN) break;
  }
  return out;
}

function fallbackLocal(topic, n){
  const arr = [];
  arr.push({ line:`MC|Which relates to ${topic}?|A) Example A;B) Example B;C) Example C;D) Example D|A` });
  const tf = { line:`TF|${topic} can be used to generate quiz questions.|T` };
  const yn = { line:`YN|Do you want more questions about ${topic}?|Y` };
  while (arr.length < n) arr.push(arr.length % 2 ? tf : yn);
  return arr.slice(0,n);
}